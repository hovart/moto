<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartbloghomelatestnews}luxuryshop>smartblog_latest_news_1fb3e1d7e905799302da60918111970d'] = 'Notre Blog';
$_MODULE['<{smartbloghomelatestnews}luxuryshop>smartblog_latest_news_43340e6cc4e88197d57f8d6d5ea50a46'] = 'En savoir plus';
