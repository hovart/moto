<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogcategories}luxuryshop>smartblogcategories_979ac0eb39f23e70f45b79282ccab548'] = 'Categorías del blog';
