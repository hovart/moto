<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbanner}prestashop>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Banner block';
$_MODULE['<{blockbanner}prestashop>blockbanner_9d9becee392c0fbcc66ff4981b8ae2f7'] = 'Displays a banner at the top of the store.';
$_MODULE['<{blockbanner}prestashop>blockbanner_126b21ce46c39d12c24058791a236777'] = 'Invalid image';
$_MODULE['<{blockbanner}prestashop>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'An error occurred while attempting to upload the file.';
$_MODULE['<{blockbanner}prestashop>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'The settings have been updated.';
$_MODULE['<{blockbanner}prestashop>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockbanner}prestashop>blockbanner_89ca5c48bbc6b7a648a5c1996767484c'] = 'Block image';
$_MODULE['<{blockbanner}prestashop>blockbanner_4c94cde88098f07d966c2800e050dd67'] = 'You can either upload the image or gives its absolute link in the option below.';
$_MODULE['<{blockbanner}prestashop>blockbanner_3013dc3fd5a9212be1495367fe0fb8d2'] = 'Image Link';
$_MODULE['<{blockbanner}prestashop>blockbanner_ef0b5453792908ee4c0153857da7a895'] = 'You can either give the image\'s absolute link or upload the image in the option above.';
$_MODULE['<{blockbanner}prestashop>blockbanner_18f2ae2bda9a34f06975d5c124643168'] = 'Image description';
$_MODULE['<{blockbanner}prestashop>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Please enter a short but meaningful description for the banner.';
$_MODULE['<{blockbanner}prestashop>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockbanner}prestashop>form_92fbf0e5d97b8afd7e73126b52bdc4bb'] = 'Choose a file';


return $_MODULE;
