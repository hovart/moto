<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogsearch}luxuryshop>smartblogsearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Buscar';
$_MODULE['<{smartblogsearch}luxuryshop>smartblogsearch_496d09a4b58f276873f653cbd25f8ced'] = 'Búsqueda de blogs';
