<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnprodcarousel}prestashop>tptnprodcarousel_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Sale';