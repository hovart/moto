<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartbloghomelatestnews}luxuryshop>smartblog_latest_news_1fb3e1d7e905799302da60918111970d'] = 'From the blog';