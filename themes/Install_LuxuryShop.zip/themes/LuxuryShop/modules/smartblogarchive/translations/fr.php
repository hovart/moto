<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_ca18b5fea5dcf5c45e7af343d97e774c'] = 'Blog Archive';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_86f5978d9b80124f509bdb71786e929e'] = 'Janvier';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_659e59f062c75f81259d22786d6c44aa'] = 'Février';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'Mars';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_3fcf026bbfffb63fb24b8de9d0446949'] = 'Avril';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_195fbb57ffe7449796d23466085ce6d8'] = 'Mai';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_688937ccaf2a2b0c45a1c9bbba09698d'] = 'Juin';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_1b539f6f34e8503c97f6d3421346b63c'] = 'Juillet';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_41ba70891fb6f39327d8ccb9b1dafb84'] = 'Août';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_cc5d90569e1c8313c2b1c2aab1401174'] = 'Septembre';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_eca60ae8611369fe28a02e2ab8c5d12e'] = 'Octobre';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_7e823b37564da492ca1629b4732289a8'] = 'Novembre';
$_MODULE['<{smartblogarchive}luxuryshop>smartblogarchive_82331503174acbae012b2004f6431fa5'] = 'Décembre';