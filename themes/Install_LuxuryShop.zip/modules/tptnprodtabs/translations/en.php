<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs-list_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Sale';