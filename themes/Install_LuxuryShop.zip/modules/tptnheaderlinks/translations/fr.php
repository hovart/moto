<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnheaderlinks}prestashop>tptnheaderlinks_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Connexion';
$_MODULE['<{tptnheaderlinks}prestashop>tptnheaderlinks_0ba7583639a274c434bbe6ef797115a4'] = 'Enregistrer';
$_MODULE['<{tptnheaderlinks}prestashop>tptnheaderlinks_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mon compte';
$_MODULE['<{tptnheaderlinks}prestashop>tptnheaderlinks_c87aacf5673fada1108c9f809d354311'] = 'Déconnexion';