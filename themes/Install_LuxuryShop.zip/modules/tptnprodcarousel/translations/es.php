<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnprodcarousel}prestashop>tptnprodcarousel_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{tptnprodcarousel}prestashop>tptnprodcarousel_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Venta';
$_MODULE['<{tptnprodcarousel}prestashop>tptnprodcarousel_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir al carrito';
$_MODULE['<{tptnprodcarousel}prestashop>tptnprodcarousel_c91e4ee170226d66e90f99ba917e4c20'] = 'Vista rápida';