<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogrelatedposts}luxuryshop>smartblogrelatedposts_177f0eb97c41c1d839bff85af7cb1120'] = 'Artículos Relacionados';
