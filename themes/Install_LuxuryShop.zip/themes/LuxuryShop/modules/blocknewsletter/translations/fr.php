<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewsletter}luxuryshop>blocknewsletter_d51fd4d937e9f12abf2f8820b9b89491'] = 'Abonnez-vous à notre newsletter et recevez les dernières offres, promotions et mises à jour';
