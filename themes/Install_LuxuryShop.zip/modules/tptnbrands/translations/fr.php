<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnbrands}prestashop>tptnbrands_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Nos Marques';
