<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_15422d54ec0d47000dc86a9820a5237e'] = 'Destacados';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Mejores ventas';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_e8b61a76a1474bbfa35e00cd33689c21'] = 'Productos destacados no están disponibles en este momento.';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_3ea4a9735e2a182e61e3caf028dcbc3e'] = 'Los nuevos productos no están disponibles en este momento.';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_1c277246a9f3a0d83d31460210789226'] = 'Especiales no están disponibles en este momento.';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs_a6c82e6f89275ef37639882ffe88ab43'] = 'Los mejores vendedores no están disponibles en este momento.';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs-list_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs-list_bb63f16d5ebfcfa8a651642a7bb2ea5c'] = 'Venta';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs-list_c91e4ee170226d66e90f99ba917e4c20'] = 'Vista rápida';
$_MODULE['<{tptnprodtabs}prestashop>tptnprodtabs-list_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir al carrito';